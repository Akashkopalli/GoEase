from django.contrib import admin
from .models import Flight, FlightBooking

admin.site.register(Flight)
admin.site.register(FlightBooking)
